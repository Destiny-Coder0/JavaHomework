package JavaHomework2;

public class AverageGreater {

  public static void main(String[] args) {

        int numbers[] = {1, 2, 3, 4, 5, 6, 7, 8, 9}; //1+2+3+...+9 = 45, 45/9 = 5 is average

        int sum = 0;
        for (int number : numbers) {
            sum += number;
        }

        double average = (double) sum / numbers.length;

        System.out.println("Numbers greater than the average:");
        for (int i = 0; i < numbers.length; i++) {
            int number = numbers[i];
            if (number > average) {
                System.out.println(number);
            }
        }
    }

}
