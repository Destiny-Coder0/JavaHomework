package JavaHomework2;

public class HigherThanAverage {

  public static void main(String[] args) {
        int array[] = {10, 20, 30, 40, 50};

        double sum = 0;
        for (int i = 0; i < array.length; i++) {
            sum += array[i];
        }
        double average = sum / array.length;

        int count = 0;
        for (int i = 0; i < array.length; i++) {
            if (array[i] > average) {
                count++;
            }
        }

        System.out.println("The average of the array is: " + average);
        System.out.println("Number of elements higher than the average: " + count);
    }

}
