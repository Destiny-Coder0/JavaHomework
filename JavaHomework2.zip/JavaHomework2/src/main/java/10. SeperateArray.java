package JavaHomework2;

public class SeperateArray {

  public static void main(String[] args) {
        int arr[] = {2, 1, 3, 4, 7, 6, 5, 9, 8};

        System.out.println("Original Array: ");
        printArray(arr);

        separateEvenOdd(arr);

        System.out.println("Array after separation of even and odd numbers: ");
        printArray(arr);
    }

    public static void separateEvenOdd(int arr[]) {
        int n = arr.length;
        int temp[] = new int[n];
        int j = 0;

        // Store even numbers in the temporary array
        for (int i = 0; i < n; i++) {
            if (arr[i] % 2 == 0) {
                temp[j++] = arr[i];
            }
        }

        // Store odd numbers in the temporary array
        for (int i = 0; i < n; i++) {
            if (arr[i] % 2 != 0) {
                temp[j++] = arr[i];
            }
        }

        for (int i = 0; i < n; i++) {
            arr[i] = temp[i];
        }
    }

    public static void printArray(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }

}
