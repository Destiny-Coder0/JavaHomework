package JavaHomework2;
import java.util.Arrays;

public class ArraySorting {

    public static void sortNumArray(int[] arr) {
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = 0; j < arr.length - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }

    public static void sortStringArray(String[] arr) {
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = 0; j < arr.length - i - 1; j++) {
              if (arr[j].compareTo(arr[j + 1]) > 0) {
                    String temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }

    public static void main(String[] args) {
        int numArray[] = {5, 7, 1, 2, 9};
        System.out.println("Original number array: " + Arrays.toString(numArray));
        sortNumArray(numArray);
        System.out.println("Sorted number array: " + Arrays.toString(numArray));


        String stringArray[] = {"red", "blue", "pink", "purple", "orange", "yellow", "black"};
        System.out.println("\nOriginal string array: " + Arrays.toString(stringArray));
        sortStringArray(stringArray);
        System.out.println("Sorted string array: " + Arrays.toString(stringArray));
    }

}
