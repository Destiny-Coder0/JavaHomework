package JavaHomework2;

public class ElementIndex {

  public static int findIndex(int arr[], int element) {
        for (int i = 0; i < arr.length; i++) {
           if (arr[i] == element) {
              return i;
           }
        }
        return -1; // Element not found
     }

     public static void main(String[] args) {
        int arr[] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        int element = 5;
        int index = findIndex(arr, element);
        System.out.println("Index of element " + element + ": " + index);
     }

}
