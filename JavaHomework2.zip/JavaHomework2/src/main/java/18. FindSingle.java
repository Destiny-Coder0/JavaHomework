package JavaHomework2;

public class FindSingle {

  public static int findSingle(int[] arr) {
        int result = 0;
        for (int i = 0; i < arr.length; i++) {
            result ^= arr[i];
        }
        return result;
    }

    public static void main(String[] args) {
        int[] arr = {2, 3, 4, 3, 4, 1, 1, 5, 6, 7, 5, 6, 7};
        System.out.println("The number that appears only once is: " + findSingle(arr));
    }

}
