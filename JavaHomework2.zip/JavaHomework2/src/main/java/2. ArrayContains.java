package JavaHomework2;

public class ArrayContains {

  public static void main(String[] args) {
        int array[] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        int val = 5;

        boolean a = false;

        for (int i = 0; i < array.length; i++) {
            if (array[i] == val) {
                a = true;
                break;
            }
        }

        if (a) {
            System.out.println("The array contains the value " + val);
        } 
        else {
            System.out.println("The array does not contain the value " + val);
        }
    }
}
