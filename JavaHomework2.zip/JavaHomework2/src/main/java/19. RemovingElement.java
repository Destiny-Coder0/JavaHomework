package JavaHomework2;
import java.util.Arrays;

public class RemovingElement {

  public static int removeElement(int nums[], int val) {
        int count = 0;
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] != val) {
                nums[count] = nums[i];
                count++;
            }
        }
        return count;
    }

    public static void main(String[] args) {
        int nums[] = {3, 2, 2, 3, 4, 5, 3, 6};
        int val = 3;

        System.out.println("Original array: " + Arrays.toString(nums));

        int newLength = removeElement(nums, val);

        System.out.println("New length after removing " + val + ": " + newLength);
        System.out.print("Array after removal: ");
        for (int i = 0; i < newLength; i++) {
            System.out.print(nums[i] + " ");
        }
    }

}
