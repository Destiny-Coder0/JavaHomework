package JavaHomework2;

public class RemoveElement {

    public static void main(String[] args)
    {  
        int arr [] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        int element = 5;    

        System.out.println("Elements before deletion " );
        for(int i = 0; i < arr.length; i++) {
            System.out.print(arr[i]+ " ");
        }

        for(int i = 0; i < arr.length; i++)
        {
            if(arr[i] == element)
            {
                for(int j = i; j < arr.length - 1; j++)
                {
                    arr[j] = arr[j+1];
                    }
                break;
                }
            }

        System.out.println();
        System.out.println("Elements after deletion " );
        for(int i = 0; i < arr.length-1; i++)
        {
            System.out.print(arr[i]+ " ");
            }  
    }
}
