package JavaHomework2;
import java.util.Scanner;

public class SpecificPosition {

  public static void main(String[] args) {
        Scanner inp = new Scanner(System.in);

        System.out.print("Enter the size of the array: ");
        int size = inp.nextInt();

        int array[] = new int[size + 1];

        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < size; i++) {
            array[i] = inp.nextInt();
        }

        System.out.print("Enter the element to insert: ");
        int element = inp.nextInt();

        System.out.print("Enter the position to insert the element (0-indexed): ");
        int position = inp.nextInt();

        if (position < 0 || position > size) {
            System.out.println("Invalid position!");
        } 
        else {
          for (int i = size; i > position; i--) {
                array[i] = array[i - 1];
            }
            array[position] = element;

            System.out.println("Array after insertion:");
            for (int i = 0; i < size + 1; i++) {
                System.out.print(array[i] + " ");
            }
            System.out.println();
        }

    }

}
