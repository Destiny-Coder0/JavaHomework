package JavaHomework2;
import java.util.Arrays;

public class CalculateMedian {

  public static void main(String[] args) {
        int array[] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        double median = calculateMedian(array);
        System.out.println("Median: " + median);
    }

    public static double calculateMedian(int array[]) {
        Arrays.sort(array);

        int length = array.length;

        if (length % 2 == 0) {
            // If the length is even, take the average of the middle two elements
            int middle1 = array[length / 2 - 1];
            int middle2 = array[length / 2];
            return (double) (middle1 + middle2) / 2;
        } 
        else {
            // If the length is odd, return the middle element
            return array[length / 2];
        }
    }

}
